""" Full assembly of the parts to form the complete network """

import torch
import torch.nn as nn
from unet_parts import DoubleConv, Down, Up, OutConv, LineAttention


class UNet(nn.Module):
    def __init__(self, n_channels, n_classes, bilinear=False, use_line_attention=True, attention_kernel_size=7):
        """
        参数:
            n_channels: 输入通道数
            n_classes: 输出类别数
            bilinear: 是否使用双线性插值上采样
            use_line_attention: 是否使用细线注意力模块
            attention_kernel_size: 注意力模块的卷积核大小
        """
        super(UNet, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear
        self.use_line_attention = use_line_attention

        self.inc = (DoubleConv(n_channels, 16))
        self.down1 = (Down(16, 32))
        self.down2 = (Down(32, 64))
        self.down3 = (Down(64, 128))
        factor = 2 if bilinear else 1
        self.down4 = (Down(128, 256 // factor))
        self.up1 = (Up(256, 128 // factor, bilinear))
        self.up2 = (Up(128, 64 // factor, bilinear))
        self.up3 = (Up(64, 32 // factor, bilinear))
        self.up4 = (Up(32, 16, bilinear))
        self.outc = (OutConv(16, n_classes))
        
        # 在多层特征上添加细线注意力模块
        if use_line_attention:
            # Encoder层的注意力（在关键层级应用）
            self.attn_x2 = LineAttention(32, kernel_size=attention_kernel_size)  # 第2层
            self.attn_x3 = LineAttention(64, kernel_size=attention_kernel_size)  # 第3层
            self.attn_x4 = LineAttention(128, kernel_size=attention_kernel_size)  # 第4层
            self.attn_x5 = LineAttention(256 // factor, kernel_size=attention_kernel_size)  # Bottleneck
            
            # Decoder层的注意力
            self.attn_up1 = LineAttention(128 // factor, kernel_size=attention_kernel_size)
            self.attn_up2 = LineAttention(64 // factor, kernel_size=attention_kernel_size)
            self.attn_up3 = LineAttention(32 // factor, kernel_size=attention_kernel_size)
            self.attn_up4 = LineAttention(16, kernel_size=attention_kernel_size)

    def forward(self, x):
        # Encoder
        x1 = self.inc(x)
        x2 = self.down1(x1)
        if self.use_line_attention:
            x2 = self.attn_x2(x2)  # 应用细线注意力
        
        x3 = self.down2(x2)
        if self.use_line_attention:
            x3 = self.attn_x3(x3)  # 应用细线注意力
        
        x4 = self.down3(x3)
        if self.use_line_attention:
            x4 = self.attn_x4(x4)  # 应用细线注意力
        
        x5 = self.down4(x4)
        if self.use_line_attention:
            x5 = self.attn_x5(x5)  # 应用细线注意力到bottleneck
        
        # Decoder
        x = self.up1(x5, x4)
        if self.use_line_attention:
            x = self.attn_up1(x)  # 应用细线注意力
        
        x = self.up2(x, x3)
        if self.use_line_attention:
            x = self.attn_up2(x)  # 应用细线注意力
        
        x = self.up3(x, x2)
        if self.use_line_attention:
            x = self.attn_up3(x)  # 应用细线注意力
        
        x = self.up4(x, x1)
        if self.use_line_attention:
            x = self.attn_up4(x)  # 应用细线注意力
        
        logits = self.outc(x)
        return logits

    def use_checkpointing(self):
        self.inc = torch.utils.checkpoint(self.inc)
        self.down1 = torch.utils.checkpoint(self.down1)
        self.down2 = torch.utils.checkpoint(self.down2)
        self.down3 = torch.utils.checkpoint(self.down3)
        self.down4 = torch.utils.checkpoint(self.down4)
        self.up1 = torch.utils.checkpoint(self.up1)
        self.up2 = torch.utils.checkpoint(self.up2)
        self.up3 = torch.utils.checkpoint(self.up3)
        self.up4 = torch.utils.checkpoint(self.up4)
        self.outc = torch.utils.checkpoint(self.outc)